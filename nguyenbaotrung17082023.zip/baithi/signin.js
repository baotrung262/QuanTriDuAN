
  
document.getElementById("registerBtn").addEventListener("click", function() {
  window.location.href = "register.html";
});

// Lấy các phần tử DOM
var emailInput = document.getElementsByName("email")[0];
var passwordInput = document.getElementsByName("psw")[0];
var loginBtn = document.getElementById("loginBtn");

// Thêm sự kiện click cho nút đăng nhập
loginBtn.addEventListener("click", function(event) {
  event.preventDefault(); // Ngăn chặn hành vi submit form mặc định

  var email = emailInput.value; // Lấy giá trị email từ input
  var password = passwordInput.value; // Lấy giá trị mật khẩu từ input

  // Kiểm tra nếu email và mật khẩu hợp lệ
  if (email && password) {
    // Chuyển hướng đến trang "baithi.html"
    window.location.href = "trangchu.html";
  } else {
    alert("Vui lòng nhập đủ email và mật khẩu."); // Thông báo nếu email hoặc mật khẩu trống
  }
});
