// Retrieve the Register button element
const registerBtn = document.getElementById("registerBtn");

// Add an event listener to the Register button
registerBtn.addEventListener("click", function(event) {
  // Prevent the default form submission behavior
  event.preventDefault();

  // Retrieve the values of the email, password, and password-repeat fields
  const email = document.getElementById("email").value;
  const password = document.getElementById("psw").value;
  const passwordRepeat = document.getElementById("psw-repeat").value;

  // Validate the email field
  if (!email) {
    alert("Please enter an email address.");
    return;
  }

  // Validate the password field
  if (!password) {
    alert("Please enter a password.");
    return;
  }

  // Validate the password-repeat field
  if (!passwordRepeat) {
    alert("Please repeat your password.");
    return;
  }

  // Check if the password and password-repeat fields match
  if (password !== passwordRepeat) {
    alert("Passwords do not match.");
    return;
  }

  // If all fields are valid, submit the form
  document.forms[0].submit();
  window.location.href = "index.html";
});